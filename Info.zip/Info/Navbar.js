import React from 'react'
import "./Navbar.css"
export default function Navbar() {
    return (
      <div className="Navabrhead">
        <div className="logo"></div>
        <div className="Navabarcomponents">
          <section>Home</section>
          <section>Home</section>
          <section>Home</section>
          <section>Login </section>
          <button className="signup">Sign up</button>
        </div>
      </div>
    );
}
